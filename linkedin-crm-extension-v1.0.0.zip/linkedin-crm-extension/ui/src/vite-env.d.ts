/// <reference types="vite/client" />
/// <reference types="@types/chrome" />