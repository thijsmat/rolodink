// Central API base URL for the UI code. Change this once for staging/production.
export const API_BASE_URL = 'https://linkedin-crm-staging-k21f8gwio-matthijs-goes-projects.vercel.app';


