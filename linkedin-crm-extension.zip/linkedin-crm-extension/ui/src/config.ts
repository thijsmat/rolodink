// Central API base URL for the UI code. Change this once for staging/production.
export const API_BASE_URL = 'https://linkedin-crm-backend-matthijs-goes-projects.vercel.app';


